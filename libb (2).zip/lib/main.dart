import 'package:flutter/material.dart';
import 'package:flutter_application_1/kategori.dart';
import 'package:flutter_application_1/login.dart';
import 'package:flutter_application_1/shared_preference.dart';
import 'package:provider/provider.dart';
import 'package:flutter_application_1/History/kesehatan_provider.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => KesehatanProvider()),
        ChangeNotifierProvider(create: (_) => SharedPreferencesProvider()),
      ],
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Flutter Demo',
        theme: ThemeData(
          useMaterial3: true,
        ),
        home: Consumer<SharedPreferencesProvider>(
          builder: (context, provider, child) {
            // Use provider.isLoggedIn() to conditionally navigate
            return provider.isLoggedIn() ? DoctorSearchPage() : LoginPage();
          },
        ));
  }
}
