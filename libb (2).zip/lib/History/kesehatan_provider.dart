import 'package:flutter/material.dart';
import 'dart:convert';

class KesehatanProvider extends ChangeNotifier {
  initialData() async {
    setData = rawatinap;
  }

  final rawatinap = {
    "data": [
      {
        "penyakit": "Pneumonia",
        "img":
            "https://i.pinimg.com/736x/6c/b9/ed/6cb9ed4c27f7ebe4f5467362fbada110.jpg",
        "spesialis": 'Pulmonologi',
        "dokter": 'dr. Zean N H Sp.P',
        "tanggal": '10 Juni 2023',
        "pembayaran": "BPJS"
      },
      {
        "penyakit": "Vertigo",
        "img":
            "https://i.pinimg.com/564x/6c/4b/a0/6c4ba046ca7538b96632acdd38058411.jpg",
        "spesialis": 'Neurolog',
        "dokter": 'dr. Cio H Sp.N',
        "tanggal": '10 September 2022',
        "pembayaran": "BPJS"
      },
      {
        "penyakit": "Gastritis",
        "img":
            "https://assets.jatimnetwork.com/crop/0x0:0x0/750x500/webp/photo/2022/06/18/1897228412.jpg",
        "spesialis": 'Gastroenterologi',
        "dokter": 'dr. Shani I Sp.PD-KGEH',
        "tanggal": '25 Oktober 2021',
        "pembayaran": "BPJS"
      },
    ]
  };
  final rawatjalan = {
    "data": [
      {
        "penyakit": "Gingivitis",
        "img":
            "https://i.pinimg.com/564x/fb/dd/1e/fbdd1e29359b8cb469581170ada88384.jpg",
        "spesialis": 'Dentist',
        "dokter": 'dr. Aran N H S.K.G',
        "tanggal": '13 Juli 2021',
        "pembayaran": "BPJS"
      },
      {
        "penyakit": "Ronten Tulang Belakang/AP-Lat-Oblique",
        "img":
            "https://i.pinimg.com/564x/2d/ef/25/2def250000678589320721c39755ded2.jpg",
        "spesialis": 'Ortopedi',
        "dokter": 'dr. Angel Christy N H Sp.OT',
        "tanggal": '17 Januari 2019',
        "pembayaran": "BPJS"
      },
    ]
  };

  dynamic _data;
  dynamic get data => _data;
  set setData(val) {
    var tmp = json.encode(val);
    _data = json.decode(tmp);

    notifyListeners();
  }

  ubahList(val) {
    if (val == 'rawatinap') {
      setData = rawatinap;
    } else {
      setData = rawatjalan;
    }
  }
}
