import 'package:flutter/material.dart';
import 'package:flutter_application_1/History/kesehatan_provider.dart';
import 'package:provider/provider.dart';

class DetailScreenHistory extends StatefulWidget {
  const DetailScreenHistory(
      {Key? key, required this.id, required this.treatmentType})
      : super(key: key);
  final String id;
  final String treatmentType;

  @override
  State<DetailScreenHistory> createState() => _DetailScreenHistoryState();
}

class _DetailScreenHistoryState extends State<DetailScreenHistory> {
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<KesehatanProvider>(context);
    final data = prov.data[widget.treatmentType]?["data"]
        ?.firstWhere((apa) => apa["id"] == widget.id);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Data Detail"),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (data != null) ...[
            Text('Diagnosa Pasien: ${data['id']}'),
            // Additional Text widgets for other properties
          ] else
            Text('Data not found'),
        ],
      ),
    );
  }
}
